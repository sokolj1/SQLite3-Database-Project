import tornado.ioloop
import tornado.web
import json
import zmq

web_port_number     = 8888
zmq_out_port_number = 13000

context = zmq.Context()
socket  = context.socket(zmq.REQ)
socket.connect("tcp://localhost:%d" % zmq_out_port_number)

class MainHandler(tornado.web.RequestHandler):
    def post(self):
        data_from_web_entry = {
          "first_name": self.get_argument("first_name"),
          "last_name":  self.get_argument("last_name"),
          "dob":        self.get_argument("dob"),
          "dod":        self.get_argument("dod")
        }

        socket.send_json(data_from_web_entry)
        zmq_receiver_response = socket.recv_json()

        self.write(zmq_receiver_response)


if __name__ == "__main__":
    app = tornado.web.Application([
      (r"/data_input_form/(.*)", tornado.web.StaticFileHandler, { "path": "http_root" }),
      (r"/data_input_request",   MainHandler)
    ], debug=True)

    print("Listening for web traffic on %d..." % web_port_number)
    print("Sending received web traffic out on ZMQ Port %d..." % zmq_out_port_number)
    app.listen(web_port_number)
    tornado.ioloop.IOLoop.current().start()
