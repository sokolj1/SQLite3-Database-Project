create table information(
    first_name  text,
    last_name   text,
    dob         date,
    dod         date
);
