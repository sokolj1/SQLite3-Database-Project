// Initialize the Calendar Objects for User Input
$("#dob").datepicker({ changeMonth: true, changeYear:  true, yearRange: "c-400:c" });
$("#dod").datepicker({ changeMonth: true, changeYear:  true, yearRange: "c-400:c" });


// Declare Functions for:
//   Reading Values from the 4 input sections
//   Sending data from the browser to the web-server over HTTP
//   Displaying the current web application status
function readDataInputs() {
  var data = {
    first_name: $("#first_name").val(),
     last_name: $("#last_name") .val(),
           dob: $("#dob")       .val(),
           dod: $("#dod")       .val()
  };

  return data;
}

function sendDataToServer(data) {
  $.ajax({
    type:    "POST",
    url:     "/data_input_request",
    data:    data,
    success: displayApplicationStatus,
    error:   displayApplicationStatus
  });
}

function displayApplicationStatus(appStatus) {
  $("#application_status").attr("class", appStatus.status);
  $("#application_status").html(appStatus.message);
}


// Bind an action to the 'Submit' button
//  When clicked - read the inputs, then send the data to the server
//  The application status is updated in between each step for debugging purposes
$("#send_data").click(function() {
  displayApplicationStatus({
    status:    "success", 
    "message": "Reading data inputs..."
  });
  var data = readDataInputs();

  displayApplicationStatus({
    status:  "success", 
    message: "Sending: " + JSON.stringify(data, null, 2)
  });
  sendDataToServer(data);
});
