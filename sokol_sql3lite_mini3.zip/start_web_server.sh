#!/bin/bash
cd Desktop

echo "[Web-Server-Script]: Starting web server..."
python web_server_main.py
echo "[Web-Server-Script]: Web server shutdown"
