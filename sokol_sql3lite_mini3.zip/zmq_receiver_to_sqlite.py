'''
Author: John Sokol
Data Gathering & Warehousing
8 December 2017
Mini Project 3: SQLite3 Database
'''

import json
import zmq
import time
import os
import sqlite3

# ZMQ socket that connects to local host
context = zmq.Context()
socket  = context.socket(zmq.REP)
socket.bind("tcp://*:13000")

# assigns database file and schema reference
file_db = 'db_file_new.db'
schema_db = 'schema_mini_3.sql'

# reference to determine of database file exists
db_is_new = not os.path.exists(file_db)

with sqlite3.connect(file_db) as init_conn:
    # if database file does NOT exist, create new database schema
    if db_is_new:
        print ('Creating database schema')
        with open(schema_db, 'rt') as f:
            schema = f.read()
        init_conn.executescript(schema)
    
        print ('Inserting initial data')
    else:
        print ('Database file exists, assume schema does as well')

while True:
    # connects to the local host to receive inputted information as a JSON file
    message = socket.recv_json()
    
    # inserts JSON file information into database table called 'information'
    insert_sql = """insert into information (first_name, last_name, dob,dod) values (?,?,?,?)"""
    with sqlite3.connect(file_db) as est_conn:
        # try/except block to prevent errors with database insertion process
        try:
            est_conn.execute(insert_sql, (message["first_name"],message["last_name"], message["dob"], message["dod"]))
        except Exception:
            print('Error in Database insertion')
        # saves added changes to the database
        est_conn.commit()
    
    # sends success message to local host
    socket.send_json({
    "status": "Successfuly updated SQLite database",
    "message": "Data sent to db_file_new %s" % json.dumps(message, indent = 2)
    })

    # queries the database with cursor method
    with sqlite3.connect(file_db) as query_conn:
        query_cursor = query_conn.cursor()
        query_cursor.execute("""select first_name, last_name, dob, dod from information""")
        
        # prints entire dataset with method fetchall()
        for observation in query_cursor.fetchall():
            first_name,last_name,dob,dod = observation
            print('%s, %s, %s, %s' % (first_name, last_name, dob, dod))

    '''
    The following is two SQL statements read the data out of the sqlite3 table from the
    command line. The first statement queries the entire table, while the second only queries the
    first_name database table column:
    
    sqlite3 db_file_new.db 'select * from information'
    John|Sokol|1994-10-26|2098-03-22
    John|Lennon|10/09/1940|12/09/1980
    Roy|Halladay|05/14/1977|11/07/2017
    Johns-MacBook-Pro:Desktop johnsokol$ sqlite3 db_file_new.db 'select first_name from information'
    John
    John
    Roy
    '''


