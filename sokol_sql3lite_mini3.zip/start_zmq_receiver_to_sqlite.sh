#!/bin/bash
cd Desktop

echo "[ZMQ->sqlite3 Script]: Starting ZMQ -> sqlite3 process"
python zmq_receiver_to_sqlite.py
echo "[ZMQ->sqlite3 Script]: ZMQ -> sqlite3 process shutdown"
